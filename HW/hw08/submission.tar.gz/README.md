Oh no the CSMajor is away from their terminal. The longer they're away the sadder they are. QUICKLY GET THEM BACK TO THEIR VSCODE EDITOR!

Use the arrow keys to direct the csmajor png towards the vscode png. Up directs you up, down directs you down, left directs you left, and right directs you right.