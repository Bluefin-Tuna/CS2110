#ifndef MAIN_H
#define MAIN_H

#include "gba.h"

struct position {
    int r;
    int c;
};

#endif
