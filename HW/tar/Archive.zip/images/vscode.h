/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 vscode vscode.png 
 * Time-stamp: Monday 04/03/2023, 04:13:54
 * 
 * Image Information
 * -----------------
 * vscode.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef VSCODE_H
#define VSCODE_H

extern const unsigned short vscode[1850];
#define VSCODE_SIZE 3700
#define VSCODE_LENGTH 1850
#define VSCODE_WIDTH 50
#define VSCODE_HEIGHT 37

#endif

