/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 shower shower.png 
 * Time-stamp: Monday 04/03/2023, 01:45:53
 * 
 * Image Information
 * -----------------
 * shower.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SHOWER_H
#define SHOWER_H

extern const unsigned short shower[625];
#define SHOWER_SIZE 1250
#define SHOWER_LENGTH 625
#define SHOWER_WIDTH 25
#define SHOWER_HEIGHT 25

#endif

