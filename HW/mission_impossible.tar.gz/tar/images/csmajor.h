/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=25x25 csmajor csmajor.png 
 * Time-stamp: Tuesday 04/04/2023, 03:13:18
 * 
 * Image Information
 * -----------------
 * csmajor.png 25@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CSMAJOR_H
#define CSMAJOR_H

extern const unsigned short csmajor[625];
#define CSMAJOR_SIZE 1250
#define CSMAJOR_LENGTH 625
#define CSMAJOR_WIDTH 25
#define CSMAJOR_HEIGHT 25

#endif

